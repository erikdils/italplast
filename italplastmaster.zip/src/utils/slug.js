export const fromCategorySlugToUrl = slug => `/catalog/${slug}/`;
export const fromProductSlugToUrl = slug => `/catalog/${slug}/`;
export const fromMaterialSlugToUrl = slug => `/materials/${slug}/`;

