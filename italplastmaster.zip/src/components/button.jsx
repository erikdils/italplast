import React from 'react';

const Button = () => {
  return <button></button>;
};

export default Button;
