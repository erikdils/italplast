const phonesstate = [
  {
    id: '1',
    title: 'Italia',
  },
  {
    id: '2',
    value: '+348-553-02-17',
    link: 'tel:+3485530217',
  },
  {
    id: '3',
    value: '+366-106-13-06',
    link: 'tel:+3661061306',
  },
  {
    id: '4',
    title: 'Bulgaria',
  },
  {
    id: '5',
    value: '+359-8-776-661-41',
    link: 'tel:+359877666141',
  },
];

export default phonesstate;
