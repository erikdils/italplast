const homepartnersstate = [
  {
    id: '1',
    imgUrl: 'partn_01.png',
    alt: 'alt',
  },
  {
    id: '2',
    imgUrl: 'partn_02.png',
    alt: 'alt',
  },
  {
    id: '3',
    imgUrl: 'partn_03.png',
    alt: 'alt',
  },
  {
    id: '4',
    imgUrl: 'partn_04.png',
    alt: 'alt',
  },
  {
    id: '5',
    imgUrl: 'partn_05.png',
    alt: 'alt',
  },
  {
    id: '6',
    imgUrl: 'partn_06.png',
    alt: 'alt',
  },
  {
    id: '7',
    imgUrl: 'partn_07.png',
    alt: 'alt',
  },
];
export default homepartnersstate;
