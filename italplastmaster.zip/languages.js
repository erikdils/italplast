module.exports = {
  languages: ['en', 'bg', 'de', 'it'],
  defaultLanguage: 'en'
};
